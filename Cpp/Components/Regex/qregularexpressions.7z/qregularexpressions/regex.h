#ifndef REGEX_H
#define REGEX_H
#include <QString>

class regex
{
public:
    regex();
    bool checkMatch(QString str);
};

#endif // REGEX_H
